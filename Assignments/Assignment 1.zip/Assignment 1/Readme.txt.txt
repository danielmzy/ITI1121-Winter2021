Solved by two

Students 	: 	Mehezabin Ahamed & Syntiche Nsungu Mavwavwa

Student No. 	: 	8524484          & 7490930

Assignment 	: 	1

Course Code	: 	ITI1121