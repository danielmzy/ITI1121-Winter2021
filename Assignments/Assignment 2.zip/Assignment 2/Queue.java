public interface Queue
{
        // TODO Fill in interface
}