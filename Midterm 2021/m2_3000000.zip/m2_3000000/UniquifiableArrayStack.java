/**
 * COPYRIGHTED MATERIAL -- DO NOT DISTRIBUTE
 *
 * @author Guy-Vincent Jourdan
 * @author Mehrdad Sabetzadeh 
 */

public class UniquifiableArrayStack<E> extends ArrayStack<E> {

	public Stack<E> uniquify() {
	  // ADD YOUR CODE HERE
	  
	  //Remove the following line when this method has been implemented
	  return null;
	}

}