Student name: Kian Zahrai
Student number: 300098986
Course code: ITI1121
Lab section: B01

This archive contains the 7 files of the lab 1, that is, this file (README.txt),
the files Q3_SquareArray.java, Q3_AverageDemo.java, Q3_ArrayInsertionDemo.java, Q3_ReverseSortDemo.java, Q5.java, and Q6.java.