public interface Map< K, V> {

    /* Make the necessary abstract method definitions */

}