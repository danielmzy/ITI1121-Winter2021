Student name: Kian Zahrai
Student number: 300098986
Course code: ITI1121
Lab section: B-01

This archive contains the 8 files of final exam, that is, this file (README.txt),
plus LinkedGrid.java, Iterator.java, Q1Test.java, UniquifiableLinkedQueue.java, LinkedQueue.java, Queue.java, Q2Test.java