Student name: Kian Zahrai
Student number: 300098986
Course code: ITI1121
Lab section: B-02

This archive contains the 4 files of lab 11, that is, this file (README.txt),
plus Iterator.java, BitList.java, Iterative.java.