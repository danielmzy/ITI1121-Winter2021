Student name: Kian Zahrai
Student number: 300098986
Course code: ITI1121
Lab section: B-02

This archive contains the 8 files of lab 5, that is, this file (README.txt),
plus Book.java, Library.java, BookComparator.java, Series.java, AbstractSeries.java, Arithmetic.java, Geometric.java.
