public interface Series {

    // implementation
    public abstract double Series();

}