Student name: Kian Zahrai
Student number: 300164246
Course code: ITI1121
Lab section: B-02

This archive contains the 3 files of lab 10, that is, this file (README.txt)
plus OrderedStructure.java, OrderedList.java. 